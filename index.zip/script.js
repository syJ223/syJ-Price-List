let rowCount = 0;

function addRow() {
  rowCount++;
  const tableBody = document.getElementById("table-body");
  const newRow = document.createElement("tr");

  newRow.innerHTML = `
    <td>${rowCount}</td>
    <td><input type="text" class="diamond" placeholder="e.g. 86" /></td>
    <td><input type="number" class="qty" oninput="calculateRow(this)" /></td>
    <td><input type="number" class="rate" oninput="calculateRow(this)" /></td>
    <td><input type="text" class="original" disabled /></td>
    <td><input type="number" class="profit" oninput="calculateRow(this)" /></td>
    <td><input type="text" class="sell" disabled /></td>
    <td><input type="number" class="usdtprofit" oninput="calculateRow(this)" /></td>
    <td><input type="text" class="usdtsell" disabled /></td>
  `;

  tableBody.appendChild(newRow);
}

function calculateRow(input) {
  const row = input.closest("tr");

  const qty = parseFloat(row.querySelector(".qty")?.value) || 0;
  const rate = parseFloat(row.querySelector(".rate")?.value) || 0;
  const profit = parseFloat(row.querySelector(".profit")?.value) || 0;
  const usdtProfit = parseFloat(row.querySelector(".usdtprofit")?.value) || 0;

  const original = qty * rate;
  const sell = original + profit;
  const usdtsell = usdtProfit + qty;

  row.querySelector(".original").value = original.toFixed(2);
  row.querySelector(".sell").value = sell.toFixed(2);
  row.querySelector(".usdtsell").value = usdtsell.toFixed(2);
}

function copyFormattedPrices() {
  const rows = document.querySelectorAll("#table-body tr");
  let output = "";

  rows.forEach(row => {
    const diamond = row.querySelector(".diamond")?.value;
    const sell = row.querySelector(".sell")?.value;

    if (diamond && sell) {
      output += `💎 ${diamond.padEnd(5)} = ${Number(sell).toLocaleString()}\n`;
    }
  });

  if (output) {
    navigator.clipboard.writeText(output).then(() => {
      alert("✅ Copied:\n\n" + output);
    });
  } else {
    alert("⚠️ No data to copy.");
  }
}

// Load 3 rows by default
addRow();
addRow();
addRow();
